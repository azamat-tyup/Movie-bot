[# Overview

This is a Telegram Movie Bot built with Python that allows users to request and download movies using simple numeric codes. The bot features a "soft subscription" system - it encourages users to subscribe to the Telegram channel and Instagram account, but allows full access even if they don't subscribe. It includes multi-language support (Uzbek, Russian, English), admin functionality for movie management, and comprehensive user tracking with download statistics.

## Current Status (August 2, 2025)
- Bot is live and fully operational
- All core features implemented and tested
- Multi-language system working
- Admin panel functional
- Soft subscription system implemented - encourages but doesn't require subscriptions
- Free access to movies via numeric codes for all users
- Users can skip subscription and still get full bot functionality

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Bot Framework Architecture
- **Core Framework**: Python Telegram Bot (python-telegram-bot library)
- **Handler Pattern**: Organized command and message handlers in separate modules
- **Event-Driven**: Callback-based interaction system for inline keyboards and user actions
- **State Management**: Pending movie uploads tracked in memory for admin workflows

## Data Storage
- **Database**: SQLite with custom Database class wrapper
- **Schema Design**: 
  - Users table with subscription status and language preferences
  - Movies table with file metadata and download tracking
  - Download history for analytics
- **File Storage**: Local filesystem storage in `/movies` directory with code-based naming

## Multi-Language System
- **Translation Management**: JSON-based language files for Uzbek, Russian, and English
- **Dynamic Loading**: Runtime language switching with user preference persistence
- **Template System**: Parameterized text templates with format string substitution

## Access Control
- **Subscription Verification**: Real-time Telegram channel membership checking via Bot API
- **Admin Authorization**: Environment variable-based admin user ID configuration
- **Two-Stage Verification**: Requires both Telegram channel subscription and Instagram follow

## Movie Management
- **Code-Based System**: Simple numeric codes for movie identification and retrieval
- **Admin Upload Workflow**: Two-step process (metadata entry, then file upload)
- **File Handling**: Automatic file extension preservation and size validation
- **Download Tracking**: Per-movie download counters for analytics

## Error Handling
- **Graceful Degradation**: Fallback to default language when translations missing
- **File Operation Safety**: Exception handling for file moves and deletions
- **API Error Management**: Telegram API error handling for subscription checks

# External Dependencies

## Telegram Bot API
- **Purpose**: Core bot functionality and user interaction
- **Integration**: Official python-telegram-bot library
- **Features Used**: Command handlers, inline keyboards, file uploads, chat member API

## Environment Configuration
- **BOT_TOKEN**: Telegram bot authentication token
- **ADMIN_IDS**: Comma-separated list of admin user IDs
- **Required Setup**: Must configure before bot operation

## Social Media Integration
- **Telegram Channel**: Subscription verification via @kinolar_olammim
- **Instagram Account**: User follow requirement for @19_xamdamov
- **Verification Method**: Telegram API for channel, honor system for Instagram

## File System Dependencies
- **Local Storage**: Movies stored in local `/movies` directory
- **Database File**: SQLite database file (`bot_database.db`)
- **Language Assets**: JSON translation files in `/languages` directory](requirements.txt)